// imagens e sons do jogo

let imagemDaEstrada;
let imagemDoAtor;
let imagemCarro;
let imagemCarro2;
let imagemCarro3;
let imagemCarro4;
let imagemCarro5;
let imagemCarro6;
let imagemCarro7;
let imagemCarro8;
let imagemCarro9;
let imagemCarro10;

//sons
let somDaTrilha;
let somDaColisao;
let somDoPonto;

function preload(){
  imagemDaEstrada = loadImage("imagens/pista-1.png");
  imagemDoAtor = loadImage("imagens/ator-1.png");
  imagemCarro = loadImage("imagens/caminhao.png");
  imagemCarro2 = loadImage("imagens/carro01.png");
  imagemCarro3 = loadImage("imagens/carro02.png");
  imagemCarro4 = loadImage("imagens/carro03.png");
  imagemCarro5 = loadImage("imagens/carro04.png");
  imagemCarro6 = loadImage("imagens/carro05.png");
  imagemCarro7 = loadImage("imagens/carro06.png");
  imagemCarro8 = loadImage("imagens/carro07.png");
  imagemCarro9 = loadImage("imagens/carro08.png");
  imagemCarro10 = loadImage("imagens/carro09.png");
  imagemCarros = [imagemCarro5, imagemCarro3,imagemCarro4,imagemCarro2, imagemCarro, imagemCarro6, imagemCarro7, imagemCarro8, imagemCarro9, imagemCarro10];
  somDaTrilha = loadSound("sons/fundoGame.mp3");
  somDaColisao = loadSound("sons/bateu.mp3");
  somDoPonto = loadSound("sons/pontuacao.mp3");
}