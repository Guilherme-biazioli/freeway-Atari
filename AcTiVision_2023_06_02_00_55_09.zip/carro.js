//código do carro

let xCarros = [800, 800, 800, 800, 800, 800, 800, 800, 800, 800];
let yCarros = [52, 95, 135, 174, 212, 255, 295, 335, 375, 410];
let velocidadeCarros = [2, 2.5, 3.2, 5, 3.3, 2.1, 4, 5, 6, 3];
let comprimentoCarro = 40;
let alturaCarro = 30;


function mostraCarro(){
   for (let i = 0; i < imagemCarros.length; i++){
     image(imagemCarros[i], xCarros[i], yCarros[i], comprimentoCarro, alturaCarro);
   }
}


function movimentaCarro(){
  for (let i = 0; i < imagemCarros.length; i++){
    xCarros[i] -= velocidadeCarros[i];
  }

}

function voltaPosicaoInicialDoCarro(){
  for (let i = 0; i < imagemCarros.length; i++){
    if (passouTodaTela(xCarros[i])){
    xCarros[i] = 800;
    }
  } 
}

function passouTodaTela(xCarro){
  return xCarro < -50;
}